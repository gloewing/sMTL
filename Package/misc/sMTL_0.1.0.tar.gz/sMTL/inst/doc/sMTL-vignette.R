## ----setup, echo = FALSE, eval = FALSE----------------------------------------
#  knitr::opts_chunk$set(comment = "#>", warning=FALSE, message=FALSE)
#  library(sMTL)
#  # output: rmarkdown::html_vignette

## ----echo = FALSE-------------------------------------------------------------
# Thanks to Yihui Xie for providing this code
# #  %\VignetteEngine{knitr::rmarkdown} 
# %\VignetteEngine{rmarkdown::render}
library(knitr)
hook_output <- knit_hooks$get("output")
knit_hooks$set(output = function(x, options) {
   lines <- options$output.lines
   if (is.null(lines)) {
     return(hook_output(x, options))  # pass to default hook
   }
   x <- unlist(strsplit(x, "\n"))
   more <- "..."
   if (length(lines)==1) {        # first n lines
     if (length(x) > lines) {
       # truncate the output, but add ....
       x <- c(head(x, lines), more)
     }
   } else {
     x <- c(more, x[lines], more)
   }
   # paste these lines together
   x <- paste(c(x, ""), collapse = "\n")
   hook_output(x, options)
 })

## ---- eval=FALSE--------------------------------------------------------------
#  library(devtools)
#  install_github("gloewing/sMTL", subdir = "Package/sMTL")

## ---- eval = FALSE------------------------------------------------------------
#  library(sMTL)
#  smtl_setup(installJulia = TRUE, installPackages = TRUE)

## ---- eval=FALSE--------------------------------------------------------------
#  library(sMTL)
#  smtl_setup(path = "/Applications/Julia-1.5.app/Contents/Resources/julia/bin")

## ---- eval=FALSE--------------------------------------------------------------
#  library(sMTL)
#  smtl_setup(path = "/Applications/Julia-1.5.app/Contents/Resources/julia/bin",
#             installJulia = FALSE,
#             installPackages = TRUE)

## ---- eval = FALSE------------------------------------------------------------
#  library(sMTL)
#  smtl_setup()

## -----------------------------------------------------------------------------
set.seed(1) # fix the seed to get a reproducible result
K <- 4 # number of datasets
p <- 100 # covariate dimension
s <- 5 # support size
q <- 7 # size of subset of covariates that can be non-zero for any task
n_k <- 50 # task sample size
N <- n_k * p # full dataset samplesize
X <- matrix( rnorm(N * p), nrow = N, ncol=p) # full design matrix
B <- matrix(1 + rnorm(K * (p+1) ), nrow = p + 1, ncol = K) # betas before making sparse
Z <- matrix(0, nrow = p, ncol = K) # matrix of supports
y <- vector(length = N) # outcome vector

# randomly sample support to make betas sparse
for(j in 1:K)     Z[1:q, j] <- sample( c( rep(1,s), rep(0, q - s) ), q, replace = FALSE )
B[-1,] <- B[-1,] * Z # make betas sparse and ensure all models have an intercept

task <- rep(1:K, each = n_k) # vector of task labels (indices)

# iterate through and make each task specific dataset
for(j in 1:K){
    indx <- which(task == j) # indices of task
    e <- rnorm(n_k)
    y[indx] <- B[1, j] + X[indx,] %*% B[-1,j] + e
}
colnames(B) <- paste0("beta_", 1:K)
rownames(B) <- c("Intercept", paste0( "X_", 1:p ) )

## -----------------------------------------------------------------------------
print(round(B[1:8,],2))

## ---- eval = FALSE------------------------------------------------------------
#  mod <- sMTL::smtl(y = y,
#                  X = X,
#                  study = task,
#                  s = 5,
#                  commonSupp = TRUE,
#                  lambda_1 = 0.001)
#  
#  print(round(mod$beta[1:8,],2))

## ---- echo = FALSE------------------------------------------------------------
# use saved estimates to output so vignette does not depend on Rmarkdown identifying Julia path independently
# write.csv(mod$beta, "/Users/gabeloewinger/Desktop/Research Final/Sparse Multi-Study/CRAN Package/Original Code used to Build Package/sMTL/vignettes/b1.csv")

# b1 <- read.csv("b1.csv")
b1 <- read.csv("../inst/extdata/b1.csv", row.names = 1)
print(round(b1[1:8,],2))

## ---- eval = FALSE------------------------------------------------------------
#  mod <- smtl(y = y,
#              X = X,
#              study = task,
#              s = 5,
#              commonSupp = TRUE,
#              lambda_2 = 2.75)
#  
#  print(round(mod$beta[1:8,],2))

## ---- eval = TRUE, echo = FALSE-----------------------------------------------
# use saved estimates to output so vignette does not depend on Rmarkdown identifying Julia path independently
# write.csv(mod$beta, "/Users/gabeloewinger/Desktop/Research Final/Sparse Multi-Study/CRAN Package/Original Code used to Build Package/sMTL/vignettes/b2.csv")

b2 <- read.csv("../inst/extdata/b2.csv", row.names = 1)
print(round(b2[1:8,],2))

## ---- eval = FALSE------------------------------------------------------------
#  mod <- smtl(y = y,
#              X = X,
#              study = task,
#              s = 5,
#              commonSupp = FALSE,
#              lambda_1 = 0.001)
#  
#  print(round(mod$beta[1:8,],2))

## ---- eval = TRUE, echo = FALSE-----------------------------------------------
# use saved estimates to output so vignette does not depend on Rmarkdown identifying Julia path independently
# write.csv(mod$beta, "/Users/gabeloewinger/Desktop/Research Final/Sparse Multi-Study/CRAN Package/Original Code used to Build Package/sMTL/vignettes/b3.csv")

b3 <- read.csv("../inst/extdata/b3.csv", row.names = 1)
print(round(b3[1:8,],2))

## ---- eval = FALSE------------------------------------------------------------
#  mod <- smtl(y = y,
#              X = X,
#              study = task,
#              s = 5,
#              commonSupp = FALSE,
#              lambda_1 = 0.001,
#              lambda_z = 0.25)
#  
#  print(round(mod$beta[1:8,], 2))

## ---- eval = TRUE, echo = FALSE-----------------------------------------------
# use saved estimates to output so vignette does not depend on Rmarkdown identifying Julia path independently
# write.csv(mod$beta, "/Users/gabeloewinger/Desktop/Research Final/Sparse Multi-Study/CRAN Package/Original Code used to Build Package/sMTL/vignettes/b4.csv")

b4 <- read.csv("../inst/extdata/b4.csv", row.names = 1)
print(round(b4[1:8,],2))

## ---- eval = FALSE------------------------------------------------------------
#  mod <- smtl(y = y,
#              X = X,
#              study = task,
#              s = 5,
#              commonSupp = FALSE,
#              lambda_1 = 0.001,
#              lambda_z = 10)
#  
#  print(round( mod$beta[1:8,], 2))

## ---- eval = TRUE, echo = FALSE-----------------------------------------------
# use saved estimates to output so vignette does not depend on Rmarkdown identifying Julia path independently
# write.csv(mod$beta, "/Users/gabeloewinger/Desktop/Research Final/Sparse Multi-Study/CRAN Package/Original Code used to Build Package/sMTL/vignettes/b5.csv")

b5 <- read.csv("../inst/extdata/b5.csv", row.names = 1)
print(round(b5[1:8,],2))

## ---- eval = FALSE------------------------------------------------------------
#  mod <- smtl(y = y,
#              X = X,
#              study = task,
#              s = 5,
#              commonSupp = FALSE,
#              lambda_2 = 0.5,
#              lambda_z = 0.1)

## ---- eval = FALSE------------------------------------------------------------
#  preds <- sMTL::predict(model = mod, X = X[1:5,])
#  
#  print( head(preds) )

## ---- eval = TRUE, echo = FALSE-----------------------------------------------
# use saved estimates to output so vignette does not depend on Rmarkdown identifying Julia path independently
# write.csv(mod$beta, 
# "/Users/gabeloewinger/Desktop/Research Final/Sparse Multi-Study/CRAN Package/Original Code used to Build Package/sMTL/vignettes/b8.csv",
# row.names = FALSE)

preds <- read.csv("../inst/extdata/b8.csv")
print( head(preds) )

## -----------------------------------------------------------------------------
set.seed(1) # fix the seed to get a reproducible result
K <- 4 # number of datasets
p <- 100 # covariate dimension
s <- 5 # support size
q <- 7 # size of subset of covariates that can be non-zero for any task
N <- 50 # full dataset samplesize
X <- matrix( rnorm(N * p), nrow = N, ncol=p) # full design matrix
B <- matrix(1 + rnorm(K * (p+1) ), nrow = p + 1, ncol = K) # betas before making sparse
Z <- matrix(0, nrow = p, ncol = K) # matrix of supports
y <- matrix(nrow = N, ncol = K) # outcome vector

# randomly sample support to make betas sparse
for(j in 1:K)     Z[1:q, j] <- sample( c( rep(1,s), rep(0, q - s) ), q, replace = FALSE )
B[-1,] <- B[-1,] * Z # make betas sparse and ensure all models have an intercept

# iterate through and make each task specific dataset
for(j in 1:K){
    e <- rnorm(N)
    y[,j] <- B[1, j] + X %*% B[-1,j] + e
}
colnames(B) <- paste0("beta_", 1:K)
rownames(B) <- c("Intercept", paste0( "X_", 1:p ) )

## -----------------------------------------------------------------------------
print(round(B[1:8,],2))

## ---- eval = FALSE------------------------------------------------------------
#  mod <- sMTL::smtl(y = y,
#                  X = X,
#                  s = 5,
#                  commonSupp = TRUE,
#                  lambda_1 = 0.001)
#  
#  print(round(mod$beta[1:8,],2))

## ---- eval = TRUE, echo = FALSE-----------------------------------------------
# use saved estimates to output so vignette does not depend on Rmarkdown identifying Julia path independently
# write.csv(mod$beta, "/Users/gabeloewinger/Desktop/Research Final/Sparse Multi-Study/CRAN Package/Original Code used to Build Package/sMTL/vignettes/b6.csv")

b6 <- read.csv("../inst/extdata/b6.csv", row.names = 1)
print(round(b6[1:8,],2))

## ---- eval = FALSE, show = FALSE----------------------------------------------
#  mod <- sMTL::smtl(y = y,
#                  X = X,
#                  s = 5,
#                  commonSupp = FALSE,
#                  lambda_1 = 0.001,
#                  lambda_z = 0.1)
#  
#  print(round(mod$beta[1:8,],2))

## ---- eval = TRUE, echo = FALSE-----------------------------------------------
# use saved estimates to output so vignette does not depend on Rmarkdown identifying Julia path independently
# write.csv(mod$beta, "/Users/gabeloewinger/Desktop/Research Final/Sparse Multi-Study/CRAN Package/Original Code used to Build Package/sMTL/vignettes/b7.csv")

b7 <- read.csv("../inst/extdata/b7.csv", row.names = 1)
print(round(b7[1:8,],2))

## -----------------------------------------------------------------------------
set.seed(1) # fix the seed to get a reproducible result
K <- 4 # number of datasets
p <- 100 # covariate dimension
s <- 5 # support size
q <- 7 # size of subset of covariates that can be non-zero for any task
n_k <- 50 # task sample size
N <- n_k * p # full dataset samplesize
X <- matrix( rnorm(N * p), nrow = N, ncol=p) # full design matrix
B <- matrix(1 + rnorm(K * (p+1) ), nrow = p + 1, ncol = K) # betas before making sparse
Z <- matrix(0, nrow = p, ncol = K) # matrix of supports
y <- vector(length = N) # outcome vector

# randomly sample support to make betas sparse
for(j in 1:K)     Z[1:q, j] <- sample( c( rep(1,s), rep(0, q - s) ), q, replace = FALSE )
B[-1,] <- B[-1,] * Z # make betas sparse and ensure all models have an intercept

task <- rep(1:K, each = n_k) # vector of task labels (indices)

# iterate through and make each task specific dataset
for(j in 1:K){
    indx <- which(task == j) # indices of task
    e <- rnorm(n_k)
    y[indx] <- B[1, j] + X[indx,] %*% B[-1,j] + e
}
colnames(B) <- paste0("beta_", 1:K)
rownames(B) <- c("Intercept", paste0( "X_", 1:p ) )

## -----------------------------------------------------------------------------
print(round(B[1:8,],2))

## ---- eval = FALSE------------------------------------------------------------
#  # tuning grid
#  grid <- data.frame(s = c(4, 4, 5, 5),
#                     lambda_1 = c(0.01, 0.1, 0.01, 0.1),
#                     lambda_2 = rep(0, 4),
#                     lambda_z = c(0.01, 0.1, 0.01, 0.1)
#                     )
#  
#  # cross validation
#  tn <- cv.smtl(y = y,
#                X = X,
#                study = task,
#                commonSupp = FALSE,
#                grid = grid,
#                nfolds = 5,
#                multiTask = FALSE)
#  
#  # model fitting
#  mod <- sMTL::smtl(y = y,
#                  X = X,
#                  study = task,
#                  s = tn$best.1se$s,
#                  commonSupp = TRUE,
#                  lambda_1 = tn$best.1se$lambda_1,
#                  lambda_z = tn$best.1se$lambda_z)

## ---- eval = FALSE------------------------------------------------------------
#  # cross validation with internally generated grid
#  tn <- cv.smtl(y = y,
#                X = X,
#                study = task,
#                commonSupp = FALSE,
#                lambda_1 = TRUE,
#                lambda_2 = FALSE,
#                lambda_z = TRUE,
#                nfolds = 5)
#  
#  # fit final model
#  mod <- smtl(y = y,
#              X = X,
#              study = task,
#              s = tn$best$s,
#              commonSupp = FALSE,
#              lambda_1 = tn$best$lambda_1,
#              lambda_z = tn$best$lambda_z)

## ---- eval = FALSE------------------------------------------------------------
#  # generate grid
#  grid <- data.frame(s = c(4,4,5,5),
#                     lambda_1 = c(0.01, 0.1,0.01, 0.1),
#                     lambda_2 = 0,
#                     lambda_z = c(0.01, 0.1,0.01, 0.1))
#  
#  # cross validation with custom grid
#  tn <- cv.smtl(y = y,
#                X = X,
#                study = task,
#                commonSupp = FALSE,
#                grid = grid,
#                nfolds = 5)
#  
#  # fit final model
#  mod <- smtl(y = y,
#              X = X,
#              study = task,
#              s = tn$best$s,
#              commonSupp = FALSE,
#              lambda_1 = tn$best$lambda_1,
#              lambda_z = tn$best$lambda_z)

## ---- eval = FALSE------------------------------------------------------------
#  # generate grid
#  grid <- data.frame(s = c(4,4,5,5),
#                     lambda_1 = c(0.01, 0.1,0.01, 0.1),
#                     lambda_2 = 0,
#                     lambda_z = c(0.01, 0.1,0.01, 0.1))
#  
#  # cross validation with custom grid
#  tn <- cv.smtl(y = y,
#                X = X,
#                study = task,
#                commonSupp = FALSE,
#                grid = grid,
#                nfolds = 5,
#                multiTask = FALSE)
#  
#  # fit final model
#  mod <- smtl(y = y,
#              X = X,
#              study = task,
#              s = tn$best$s,
#              commonSupp = FALSE,
#              lambda_1 = tn$best$lambda_1,
#              lambda_z = tn$best$lambda_2)

## ---- eval = FALSE------------------------------------------------------------
#  # cross validation with custom grid using
#  tn <- cv.smtl(y = y,
#                X = X,
#                study = task,
#                commonSupp = FALSE,
#                grid = grid,
#                LocSrch_skip = 3,
#                LocSrch_maxIter = 5,
#                nfolds = 5,
#                multiTask = FALSE)

## ---- eval = FALSE------------------------------------------------------------
#  ######################################
#  # generate initial tuning grid
#  ######################################
#  s <- c(5, 10, 15, 20)
#  lambda_1 <- c(1e-6) # small fixed ridge penalty for regularization
#  lambda_2 <- 0
#  lambda_z <- sort( unique( c(0, 1e-6, 1e-5, 1e-4, 1e-3,
#                              exp(-seq(0,5, length = 8)),  1, 3) ),  decreasing = TRUE )
#  
#  grid <- expand.grid(s, lambda_1, lambda_2, lambda_z)
#  colnames(grid) <- c("s", "lambda_1", "lambda_2", "lambda_z")
#  
#  # order correctly
#  grid <- grid[  order(-grid$s,
#                        grid$lambda_1,
#                        -grid$lambda_z,
#                        decreasing=TRUE),     ]
#  ###################################################
#  # stage 1: cross validation with initial grid
#  ###################################################
#  tn <- cv.smtl(y = y,
#                X = X,
#                study = task,
#                commonSupp = FALSE,
#                grid = grid,
#                nfolds = 5,
#                multiTask = FALSE)
#  
#  #############################################################################
#  # create second grid with optimal hyperparameters from stage 1
#  #############################################################################
#  # new sparsity grid
#  s <- tn$best$s
#  s <- c(s-2, s, s+2)
#  s <- s[s >= 1]
#  
#  # ridge penalty grid
#  lambda_1 <- c(1e-7, 1e-5, 1e-3, 1e-1)
#  
#  # new lambda_z grid
#  lambda_z <- tn$best$lambda_z
#  lambda_z <- sort( c( seq(1.5, 10, length = 5), seq(0.1, 1, length = 5) ) * lambda_z, decreasing = TRUE)
#  lambda_z <- lambda_z[lambda_z <= 10] # make sure this is below a threshold to prevent numerical issues
#  
#  grid <- as.data.frame(  expand.grid( lambda_1, lambda_2, lambda_z, s) )
#  colnames(grid) <- c("lambda_1", "lambda_2", "lambda_z", "s")
#  
#  # order correctly
#  grid <- grid[  order(-grid$s,
#                        grid$lambda_1,
#                        -grid$lambda_z,
#                        decreasing=TRUE),     ]
#  
#  ###################################################
#  # stage 2: cross validation with updated grid
#  ###################################################
#  tn <- cv.smtl(y = y,
#                X = X,
#                study = task,
#                commonSupp = FALSE,
#                grid = grid,
#                nfolds = 5,
#                multiTask = FALSE)

## ---- eval = FALSE------------------------------------------------------------
#  mod <- smtl(y = y,
#              X = X,
#              study = task,
#              s = 5,
#              commonSupp = FALSE,
#              lambda_1 = c(0.1, 0.2, 0.3),
#              lambda_z = c(0.01, 0.05, 0.1)
#              )

## ---- eval = FALSE------------------------------------------------------------
#  preds <- sMTL::predict(model = mod,
#                         X = X,
#                         lambda_1 = 0.1,
#                         lambda_z = 0.01)

## ---- eval = FALSE------------------------------------------------------------
#  # save path of Julia binary location on your computer
#  # ***replace with your computer's path***
#  path <- "/Applications/Julia-1.7.app/Contents/Resources/julia/bin"
#  
#  # set so JuliaConnectoR can access Julia installation
#  Sys.setenv(JULIA_BINDIR = path )

## ---- eval = FALSE------------------------------------------------------------
#  # find path of sMTL package installation on your computer
#  smtl_path <- paste0( .libPaths("sMTL"), "/sMTL/julia_path/" )
#  smtl_path <- smtl_path[length(smtl_path)] # use most recent
#  
#  # save Julia path for sMTL package directory for future use
#  fileConn <- file( paste0(smtl_path, "julia.path.txt") )
#  base::writeLines(path, fileConn) # save new julia path
#  close(fileConn)

